# -*- coding: utf-8 -*-

from . import HrCandidate
from . import HrJobPosition
from . import HrCandidateOffer
from . import HrCandidateTag